'use strict';

(() => {
  const galleryCards = Array.from(document.querySelectorAll('.gallery-card'));
  const filterButtons = Array.from(document.querySelectorAll('.filter-button'));
  const filterStatus = document.querySelector('#filter-status');

  const lightbox = document.querySelector('#lightbox');
  const lightboxImage = document.querySelector('#lightbox-image');
  const lightboxTitle = document.querySelector('#lightbox-title');
  const lightboxDescription = document.querySelector('#lightbox-description');
  const lightboxCounter = document.querySelector('#lightbox-counter');
  const closeButton = document.querySelector('.lightbox__close');
  const previousButton = document.querySelector('.lightbox__nav--previous');
  const nextButton = document.querySelector('.lightbox__nav--next');
  const backdrop = document.querySelector('.lightbox__backdrop');
  const currentYear = document.querySelector('#current-year');

  let visibleCards = [...galleryCards];
  let currentIndex = 0;
  let previouslyFocusedElement = null;
  let pointerStartX = null;

  const getCardData = (card) => {
    const image = card.querySelector('img');
    const title = card.querySelector('.gallery-card__title')?.textContent.trim() || 'Gallery image';
    const category = card.querySelector('.gallery-card__category')?.textContent.trim() || '';

    return {
      fullSource: image.dataset.full || image.currentSrc || image.src,
      alt: image.alt,
      title,
      category
    };
  };

  const updateLightboxContent = () => {
    const card = visibleCards[currentIndex];
    if (!card) return;

    const data = getCardData(card);
    lightboxImage.src = data.fullSource;
    lightboxImage.alt = data.alt;
    lightboxTitle.textContent = data.title;
    lightboxDescription.textContent = data.category;
    lightboxCounter.textContent = `${currentIndex + 1} / ${visibleCards.length}`;

    previousButton.disabled = visibleCards.length <= 1;
    nextButton.disabled = visibleCards.length <= 1;
  };

  const openLightbox = (card) => {
    visibleCards = galleryCards.filter((item) => !item.hidden);
    currentIndex = Math.max(0, visibleCards.indexOf(card));
    previouslyFocusedElement = document.activeElement;

    updateLightboxContent();
    lightbox.hidden = false;
    document.body.classList.add('is-lightbox-open');
    closeButton.focus();
  };

  const closeLightbox = () => {
    if (lightbox.hidden) return;

    lightbox.hidden = true;
    document.body.classList.remove('is-lightbox-open');
    lightboxImage.src = '';

    if (previouslyFocusedElement instanceof HTMLElement) {
      previouslyFocusedElement.focus();
    }
  };

  const showRelativeImage = (direction) => {
    if (visibleCards.length <= 1) return;
    currentIndex = (currentIndex + direction + visibleCards.length) % visibleCards.length;
    updateLightboxContent();
  };

  const applyFilter = (filter) => {
    galleryCards.forEach((card) => {
      const shouldShow = filter === 'all' || card.dataset.category === filter;
      card.hidden = !shouldShow;
    });

    visibleCards = galleryCards.filter((card) => !card.hidden);
    filterStatus.textContent = `${visibleCards.length} image${visibleCards.length === 1 ? '' : 's'} shown.`;
  };

  const trapFocus = (event) => {
    if (event.key !== 'Tab' || lightbox.hidden) return;

    const focusableElements = Array.from(
      lightbox.querySelectorAll('button:not([disabled]), [href], [tabindex]:not([tabindex="-1"])')
    ).filter((element) => !element.hidden);

    if (focusableElements.length === 0) return;

    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];

    if (event.shiftKey && document.activeElement === firstElement) {
      event.preventDefault();
      lastElement.focus();
    } else if (!event.shiftKey && document.activeElement === lastElement) {
      event.preventDefault();
      firstElement.focus();
    }
  };

  filterButtons.forEach((button) => {
    button.addEventListener('click', () => {
      filterButtons.forEach((item) => {
        const isActive = item === button;
        item.classList.toggle('is-active', isActive);
        item.setAttribute('aria-pressed', String(isActive));
      });

      applyFilter(button.dataset.filter || 'all');
    });
  });

  galleryCards.forEach((card) => {
    const trigger = card.querySelector('.gallery-card__trigger');
    trigger?.addEventListener('click', () => openLightbox(card));
  });

  closeButton.addEventListener('click', closeLightbox);
  previousButton.addEventListener('click', () => showRelativeImage(-1));
  nextButton.addEventListener('click', () => showRelativeImage(1));
  backdrop.addEventListener('click', closeLightbox);

  lightbox.addEventListener('pointerdown', (event) => {
    pointerStartX = event.clientX;
  });

  lightbox.addEventListener('pointerup', (event) => {
    if (pointerStartX === null) return;
    const distance = event.clientX - pointerStartX;
    pointerStartX = null;

    if (Math.abs(distance) < 60) return;
    showRelativeImage(distance > 0 ? -1 : 1);
  });

  document.addEventListener('keydown', (event) => {
    if (lightbox.hidden) return;

    if (event.key === 'Escape') closeLightbox();
    if (event.key === 'ArrowLeft') showRelativeImage(-1);
    if (event.key === 'ArrowRight') showRelativeImage(1);
    trapFocus(event);
  });

  if (currentYear) {
    currentYear.textContent = String(new Date().getFullYear());
  }

  applyFilter('all');
})();
