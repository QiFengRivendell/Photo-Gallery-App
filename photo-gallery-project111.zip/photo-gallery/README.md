# Luma Gallery — Responsive Photo Gallery

一个不依赖框架或第三方库的响应式 Photo Gallery 项目，可直接在 Visual Studio Code 中运行。

## 功能

- 响应式 CSS Grid 图片布局
- All / Nature / City / Travel / Abstract 分类筛选
- 点击图片打开全屏 Lightbox
- 上一张、下一张、循环浏览
- 键盘支持：`Esc` 关闭，`←` / `→` 切换，`Tab` 焦点循环
- 手机端左右滑动切换图片
- 图片懒加载和独立缩略图
- 语义化 HTML、ARIA、Skip Link、清晰的焦点样式
- SEO meta tags、Open Graph 信息和 `robots.txt`
- `prefers-reduced-motion` 动效降级支持
- 完全本地图片，无网络时也可运行

## 项目结构

```text
photo-gallery/
├── index.html
├── README.md
├── LICENSE
├── robots.txt
├── .gitignore
├── css/
│   ├── style.css
│   └── style.min.css
├── js/
│   ├── main.js
│   └── main.min.js
├── assets/
│   ├── favicon.svg
│   └── images/
│       ├── full/       # Lightbox 使用的大图
│       └── thumbs/     # 页面网格使用的缩略图
└── docs/
    ├── project-plan.md
    └── wireframe.md
```

## 在 VS Code 中运行

### 方法一：使用 Live Server 扩展

1. 使用 VS Code 打开整个 `photo-gallery` 文件夹。
2. 在 Extensions 中搜索并安装 **Live Server**。
3. 右键 `index.html`。
4. 点击 **Open with Live Server**。
5. 浏览器会自动打开项目。

### 方法二：直接打开

直接双击 `index.html` 也可以运行。这个项目没有模块导入或后端依赖，因此主要功能仍然可用。

### 方法三：使用本地服务器

电脑安装了 Python 时，在项目根目录运行：

```bash
python -m http.server 5500
```

然后访问：

```text
http://localhost:5500
```

## 修改图片

1. 把缩略图放入 `assets/images/thumbs/`。
2. 把对应大图放入 `assets/images/full/`。
3. 在 `index.html` 中复制一个 `.gallery-card`。
4. 修改以下内容：
   - `data-category`
   - 缩略图 `src`
   - 大图 `data-full`
   - 图片 `alt`
   - 标题和分类

推荐尺寸：

- 缩略图：约 `720 × 480`
- 大图：约 `1600 × 1067`
- 推荐格式：WebP

## 修改分类

筛选按钮：

```html
<button class="filter-button" data-filter="nature">Nature</button>
```

图片卡片：

```html
<figure class="gallery-card" data-category="nature">
```

按钮的 `data-filter` 必须与卡片的 `data-category` 完全一致。

## 使用压缩文件部署

开发阶段默认使用可读版本：

```html
<link rel="stylesheet" href="css/style.css">
<script src="js/main.js" defer></script>
```

部署时可以改为：

```html
<link rel="stylesheet" href="css/style.min.css">
<script src="js/main.min.js" defer></script>
```

## Git 和 GitHub 初始化

在项目根目录运行：

```bash
git init
git add .
git commit -m "Build responsive photo gallery"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

## GitHub Pages 部署

1. 将项目推送到 GitHub。
2. 打开 repository 的 **Settings**。
3. 选择 **Pages**。
4. Source 选择 **Deploy from a branch**。
5. Branch 选择 `main`，文件夹选择 `/root`。
6. 保存并等待 GitHub 生成网站地址。

## Netlify 部署

可以直接把整个 `photo-gallery` 文件夹拖到 Netlify 的部署页面，不需要 build command。

## Vercel 部署

导入 GitHub repository，Framework Preset 选择 **Other**，不需要 Build Command，Output Directory 留空。

## SEO 上线前检查

- 把 `meta name="author"` 改成你的名字。
- 根据网站内容修改标题和描述。
- 部署后添加 canonical URL。
- 添加真实网站 URL 的 Open Graph URL。
- 若需要 sitemap，使用部署后的真实域名生成。

## Accessibility 检查

- 每张图片都有说明性 `alt`。
- 所有功能均可使用键盘操作。
- Lightbox 使用 `role="dialog"` 和 `aria-modal="true"`。
- 筛选结果通过 `aria-live` 通知屏幕阅读器。
- 页面支持跳过导航。
- 焦点状态不会被隐藏。
- 用户关闭动画偏好时，页面会减少动效。

## 浏览器测试建议

至少测试：

- Google Chrome
- Microsoft Edge
- Mozilla Firefox
- Safari
- Chrome Android 或 Safari iOS

重点检查：筛选、Lightbox、键盘操作、手机布局和图片加载。

## 说明

项目中的示例图片是为演示界面而制作的本地示例素材。提交课程作业时，可以换成自己的摄影作品或具备合法使用权的图片。
